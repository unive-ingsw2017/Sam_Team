package com.example.alessio.safeschool;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ActivityInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_info);
    }

}

