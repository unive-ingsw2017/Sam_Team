package com.example.alessio.safeschool;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStates;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.maps.android.clustering.ClusterManager;

import java.io.IOException;
import java.util.ArrayList;


public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        GoogleMap.OnMapClickListener, GoogleMap.OnMapLongClickListener, GoogleMap.OnCameraMoveStartedListener, GoogleMap.OnMarkerClickListener, GoogleMap.OnInfoWindowClickListener {


    static ArrayList<String> province = new ArrayList<>();
    static ArrayList<String> vincoli = new ArrayList<>();
    static ArrayList<String> grado = new ArrayList<>();
    static DataBaseHelper mDBHelper;
    static DbManager dbm;
    static SQLiteDatabase mDb;
    protected static final int REQUEST_CHECK_SETTINGS = 500;
    protected static final int PERMISSIONS_REQUEST_ACCESS_BOTH_LOCATION = 501;
    // alcune costanti
    private static final String TAG = "MapsActivity";
    /**
     * Questo oggetto è la mappa di Google Maps. Viene inizializzato asincronamente dal metodo {@code onMapsReady}.
     */
    protected GoogleMap gMap;
    /**
     * API per i servizi di localizzazione.
     */
    protected FusedLocationProviderClient fusedLocationClient;
    /**
     * Posizione corrente. Potrebbe essere null prima di essere calcolata la prima volta.
     */
    @Nullable
    protected LatLng currentPosition = null;


    /**
     * Questo metodo viene invocato quando viene inizializzata questa activity.
     * Si tratta di una sorta di "main" dell'intera activity.
     * Inizializza i campi d'istanza, imposta alcuni listener e svolge gran parte delle operazioni "globali" dell'activity.
     *
     * @param savedInstanceState bundle con lo stato dell'activity.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        province.clear();
        grado.clear();
        vincoli.clear();


        mDBHelper = new DataBaseHelper(MapsActivity.this);
        dbm = new DbManager(MapsActivity.this);

        try {
            mDBHelper.updateDataBase();
        } catch (IOException mIOException) {
            throw new Error("UnableToUpdateDatabase");
        }

        try {
            mDb = mDBHelper.getWritableDatabase();
        } catch (SQLException mSQLException) {
            throw mSQLException;
        }



        // inizializza le preferenze
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false);

        // API per i servizi di localizzazione
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // inizializza la mappa asincronamente
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    // ciclo di vita della app
    //

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    /**
     * Applica le impostazioni (preferenze) della mappa ad ogni chiamata.
     */
    @Override
    protected void onResume() {
        super.onResume();
        applyMapSettings();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    /**
     * Pulisce la mappa quando l'app viene distrutta.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        gMap.clear();
    }

    /**
     * Quando arriva un Intent viene eseguito questo metodo.
     * Può essere esteso e modificato secondo le necessità.
     *
     * @see Activity#onActivityResult(int, int, Intent)
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        final LocationSettingsStates states = LocationSettingsStates.fromIntent(intent);
        switch (requestCode) {
            case REQUEST_CHECK_SETTINGS:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        // inserire codice qui
                        break;
                    case Activity.RESULT_CANCELED:
                        // o qui
                        break;
                    default:
                        break;
                }
                break;
        }
    }

    /**
     * Questo metodo viene chiamato quando viene richiesto un permesso.
     * Si tratta di un pattern asincrono che va gestito come qui impostato: per gestire nuovi permessi, qualora dovesse essere necessario,
     * è possibile riprodurre un comportamento simile a quello già implementato.
     *
     * @param requestCode  codice di richiesta.
     * @param permissions  array con i permessi richiesti.
     * @param grantResults array con l'azione da intraprende per ciascun dei permessi richiesti.
     * @see Activity#onRequestPermissionsResult(int, String[], int[])
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case PERMISSIONS_REQUEST_ACCESS_BOTH_LOCATION: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "permissions granted: ACCESS_FINE_LOCATION + ACCESS_COARSE_LOCATION");
                } else {
                    Log.e(TAG, "permissions not granted: ACCESS_FINE_LOCATION + ACCESS_COARSE_LOCATION");
                    Snackbar.make(this.findViewById(R.id.map), R.string.msg_permissions_not_granted, Snackbar.LENGTH_LONG);
                }
            }
        }
    }

    /**
     * Invocato quando viene creato il menu delle impostazioni.
     *
     * @param menu l'oggetto menu.
     * @return ritornare true per visualizzare il menu.
     * @see Activity#onCreateOptionsMenu(Menu)
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.navigation_map, menu);
        return true;
    }

    /**
     * Invocato quando viene cliccata una voce nel menu delle impostazioni.
     *
     * @param item la voce di menu cliccata.
     * @return ritorna true per continuare a chiamare altre callback; false altrimenti.
     * @see Activity#onOptionsItemSelected(MenuItem)
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Impostazioni:
                startActivity(new Intent(this, SettingsActivity.class));
                break;
            case R.id.navigation_home:
                startActivity(new Intent(this, ActivityInfo.class));
                break;
            case R.id.navigation_notifications:
                startActivity(new Intent(this, Tutorial.class));
                break;
            case R.id.filtri:
                gMap.clear();
                mClusterManager.clearItems();
                invalidateOptionsMenu();
                province.clear();
                grado.clear();
                vincoli.clear();
                queryfiltra();
                break;
            case R.id.infanzia:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=grado.indexOf((Object) "SCUOLA INFANZIA");
                    grado.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    grado.add("SCUOLA INFANZIA");
                    queryfiltra();
                }
                break;
            case R.id.primaria:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=grado.indexOf((Object) "SCUOLA PRIMARIA");
                    grado.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    grado.add("SCUOLA PRIMARIA");
                    queryfiltra();
                }
                break;
            case R.id.primo:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=grado.indexOf((Object) "SCUOLA PRIMO GRADO");
                    grado.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    grado.add("SCUOLA PRIMO GRADO");
                    queryfiltra();
                }
                break;
            case R.id.compr:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=grado.indexOf((Object) "ISTITUTO COMPRENSIVO");
                    grado.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    grado.add("ISTITUTO COMPRENSIVO");
                    queryfiltra();
                }
                break;
            case R.id.licei:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=grado.indexOf((Object) "ALTRO");
                    grado.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    grado.add("ALTRO");
                    queryfiltra();
                }
                break;
            case R.id.p1:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=vincoli.indexOf((Object) "vincoli_idrogeologici");
                    vincoli.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    vincoli.add("vincoli_idrogeologici");
                    queryfiltra();
                }
                break;
            case R.id.p2:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=vincoli.indexOf((Object) "vincoli_paesaggio");
                    vincoli.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    vincoli.add("vincoli_paesaggio");
                    queryfiltra();
                }
                break;
            case R.id.p3:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=vincoli.indexOf((Object) "edificio_vetusto");
                    vincoli.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    vincoli.add("edificio_vetusto");
                    queryfiltra();
                }
                break;
            case R.id.p4:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=vincoli.indexOf((Object) "progettazione_antisismica");
                    vincoli.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    vincoli.add("progettazione_antisismica");
                    queryfiltra();
                }
                break;
            case R.id.tv:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=province.indexOf((Object) item.getTitle());
                    province.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    province.add((String)item.getTitle());
                    queryfiltra();
                }
                break;
            case R.id.pd:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=province.indexOf((Object) item.getTitle());
                    province.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    province.add((String)item.getTitle());
                    queryfiltra();
                }
                break;
            case R.id.vi:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=province.indexOf((Object) item.getTitle());
                    province.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    province.add((String)item.getTitle());
                    queryfiltra();
                }
                break;
            case R.id.vr:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=province.indexOf((Object) item.getTitle());
                    province.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    province.add((String)item.getTitle());
                    queryfiltra();
                }
                break;
            case R.id.bl:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=province.indexOf((Object) item.getTitle());
                    province.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    province.add((String)item.getTitle());
                    queryfiltra();
                }
                break;
            case R.id.rg:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=province.indexOf((Object) item.getTitle());
                    province.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    province.add((String)item.getTitle());
                    queryfiltra();
                }
                break;
            case R.id.ve:
                gMap.clear();
                mClusterManager.clearItems();
                if(item.isChecked()) {
                    item.setChecked(false);
                    int i;
                    i=province.indexOf((Object) item.getTitle());
                    province.remove(i);
                    queryfiltra();
                }
                else {
                    item.setChecked(true);
                    province.add((String)item.getTitle());
                    queryfiltra();
                }
                break;

            default:
                return super.onOptionsItemSelected(item);

        }
        return false;
    }


    public void queryfiltra (){
        if((province.isEmpty()||province.size()==7)&&(vincoli.isEmpty())&&(grado.isEmpty()||grado.size()==4)){
            String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola";
            Cursor cursor = dbm.query(query, null);
            inserimento(cursor);
        }
        else{
            if (vincoli.isEmpty()&&(grado.isEmpty())) {
                for (String provincia : province) {
                    String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.provincia=?";
                    Cursor cursor = dbm.query(query, new String[]{provincia});
                    inserimento(cursor);
                }
            }
            else{
                if (vincoli.isEmpty()&&(province.isEmpty())) {
                    for (String grado : grado) {
                        if (grado.equals("ALTRO")){
                            String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione<>'SCUOLA INFANZIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMARIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMO GRADO' and scuole.tipologia_grado_istruzione<>'ISTITUTO COMPRENSIVO'";
                            Cursor cursor = dbm.query(query, null);
                            inserimento(cursor);
                        }
                        else{
                            String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione=?";
                            Cursor cursor = dbm.query(query, new String[]{grado});
                            inserimento(cursor);
                        }
                    }
                }
                else {
                    if ((province.isEmpty()) && (grado.isEmpty())) {
                        switch (vincoli.size()) {
                            case 1:
                                String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where vincoli." + vincoli.get(0) + "='SI'";
                                Cursor cursor = dbm.query(query, null);
                                inserimento(cursor);
                                break;
                            case 2:
                                query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI'";
                                cursor = dbm.query(query, null);
                                inserimento(cursor);
                                break;
                            case 3:
                                query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI' and vincoli." + vincoli.get(2) + "='SI'";
                                cursor = dbm.query(query, null);
                                inserimento(cursor);
                                break;
                            case 4:
                                query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI' and vincoli." + vincoli.get(2) + "='SI' and vincoli." + vincoli.get(3) + "='SI'";
                                cursor = dbm.query(query, null);
                                inserimento(cursor);
                                break;
                        }
                    }
                    else {
                        if (vincoli.isEmpty()) {
                            for (String provincia : province) {
                                for (String grado : grado) {
                                    if (grado.equals("ALTRO")){
                                        String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.provincia=? and scuole.tipologia_grado_istruzione<>'SCUOLA INFANZIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMARIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMO GRADO' and scuole.tipologia_grado_istruzione<>'ISTITUTO COMPRENSIVO'";
                                        Cursor cursor = dbm.query(query, new String[]{provincia});
                                        inserimento(cursor);
                                    }
                                    else {
                                        String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.provincia=? and scuole.tipologia_grado_istruzione=?";
                                        Cursor cursor = dbm.query(query, new String[]{provincia, grado});
                                        inserimento(cursor);
                                    }
                                }
                            }
                        }
                        if (province.isEmpty()) {
                            for (String grado : grado) {
                                if (grado.equals("ALTRO")){
                                    switch (vincoli.size()) {
                                        case 1:
                                            String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione<>'SCUOLA INFANZIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMARIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMO GRADO' and scuole.tipologia_grado_istruzione<>'ISTITUTO COMPRENSIVO' and vincoli." + vincoli.get(0) + "='SI'";
                                            Cursor cursor = dbm.query(query, null);
                                            inserimento(cursor);
                                            break;
                                        case 2:
                                            query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione<>'SCUOLA INFANZIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMARIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMO GRADO' and scuole.tipologia_grado_istruzione<>'ISTITUTO COMPRENSIVO' and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI'";
                                            cursor = dbm.query(query, null);
                                            inserimento(cursor);
                                            break;
                                        case 3:
                                            query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione<>'SCUOLA INFANZIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMARIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMO GRADO' and scuole.tipologia_grado_istruzione<>'ISTITUTO COMPRENSIVO' and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI' and vincoli." + vincoli.get(2) + "='SI'";
                                            cursor = dbm.query(query, null);
                                            inserimento(cursor);
                                            break;
                                        case 4:
                                            query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione<>'SCUOLA INFANZIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMARIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMO GRADO' and scuole.tipologia_grado_istruzione<>'ISTITUTO COMPRENSIVO' and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI' and vincoli." + vincoli.get(2) + "='SI' and vincoli." + vincoli.get(3) + "='SI'";
                                            cursor = dbm.query(query, null);
                                            inserimento(cursor);
                                            break;
                                    }
                                }
                                else {
                                    switch (vincoli.size()) {
                                        case 1:
                                            String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione=? and vincoli." + vincoli.get(0) + "='SI'";
                                            Cursor cursor = dbm.query(query, new String[]{grado});
                                            inserimento(cursor);
                                            break;
                                        case 2:
                                            query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione=? and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI'";
                                            cursor = dbm.query(query, new String[]{grado});
                                            inserimento(cursor);
                                            break;
                                        case 3:
                                            query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione=? and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI' and vincoli." + vincoli.get(2) + "='SI'";
                                            cursor = dbm.query(query, new String[]{grado});
                                            inserimento(cursor);
                                            break;
                                        case 4:
                                            query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione=? and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI' and vincoli." + vincoli.get(2) + "='SI' and vincoli." + vincoli.get(3) + "='SI'";
                                            cursor = dbm.query(query, new String[]{grado});
                                            inserimento(cursor);
                                            break;
                                    }
                                }
                            }
                        }
                        if (grado.isEmpty()) {
                            switch (vincoli.size()) {
                                case 1:
                                    for (String provincia : province) {
                                        String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.provincia=? and vincoli." + vincoli.get(0) + "='SI'";
                                        Cursor cursor = dbm.query(query, new String[]{provincia});
                                        inserimento(cursor);
                                    }
                                    break;
                                case 2:
                                    for (String provincia : province) {
                                        String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.provincia=? and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI'";
                                        Cursor cursor = dbm.query(query, new String[]{provincia});
                                        inserimento(cursor);
                                    }
                                    break;
                                case 3:
                                    for (String provincia : province) {
                                        String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.provincia=? and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI' and vincoli." + vincoli.get(2) + "='SI'";
                                        Cursor cursor = dbm.query(query, new String[]{provincia});
                                        inserimento(cursor);
                                    }
                                    break;
                                case 4:
                                    for (String provincia : province) {
                                        String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.provincia=? and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI' and vincoli." + vincoli.get(2) + "='SI' and vincoli." + vincoli.get(3) + "='SI'";
                                        Cursor cursor = dbm.query(query, new String[]{provincia});
                                        inserimento(cursor);
                                    }
                                    break;
                            }
                        }
                        else {
                            for (String grado : grado) {
                                if (grado.equals("ALTRO")){
                                    switch (vincoli.size()) {
                                        case 1:
                                            for (String provincia : province) {
                                                String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione<>'SCUOLA INFANZIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMARIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMO GRADO' and scuole.tipologia_grado_istruzione<>'ISTITUTO COMPRENSIVO' and scuole.provincia=? and vincoli." + vincoli.get(0) + "='SI'";
                                                Cursor cursor = dbm.query(query, new String[]{provincia});
                                                inserimento(cursor);
                                            }
                                            break;
                                        case 2:
                                            for (String provincia : province) {
                                                String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione<>'SCUOLA INFANZIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMARIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMO GRADO' and scuole.tipologia_grado_istruzione<>'ISTITUTO COMPRENSIVO' and scuole.provincia=? and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI'";
                                                Cursor cursor = dbm.query(query, new String[]{provincia});
                                                inserimento(cursor);
                                            }
                                            break;
                                        case 3:
                                            for (String provincia : province) {
                                                String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione<>'SCUOLA INFANZIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMARIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMO GRADO' and scuole.tipologia_grado_istruzione<>'ISTITUTO COMPRENSIVO' and scuole.provincia=? and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI' and vincoli." + vincoli.get(2) + "='SI'";
                                                Cursor cursor = dbm.query(query, new String[]{provincia});
                                                inserimento(cursor);
                                            }
                                            break;
                                        case 4:
                                            for (String provincia : province) {
                                                String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.tipologia_grado_istruzione<>'SCUOLA INFANZIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMARIA' and scuole.tipologia_grado_istruzione<>'SCUOLA PRIMO GRADO' and scuole.tipologia_grado_istruzione<>'ISTITUTO COMPRENSIVO' and scuole.provincia=? and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI' and vincoli." + vincoli.get(2) + "='SI' and vincoli." + vincoli.get(3) + "='SI'";
                                                Cursor cursor = dbm.query(query, new String[]{provincia});
                                                inserimento(cursor);
                                            }
                                            break;
                                    }
                                }
                                else {
                                    switch (vincoli.size()) {
                                        case 1:
                                            for (String provincia : province) {
                                                String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.provincia=? and scuole.tipologia_grado_istruzione=? and vincoli." + vincoli.get(0) + "='SI'";
                                                Cursor cursor = dbm.query(query, new String[]{provincia, grado});
                                                inserimento(cursor);
                                            }
                                            break;
                                        case 2:
                                            for (String provincia : province) {
                                                String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.provincia=? and scuole.tipologia_grado_istruzione=? and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI'";
                                                Cursor cursor = dbm.query(query, new String[]{provincia, grado});
                                                inserimento(cursor);
                                            }
                                            break;
                                        case 3:
                                            for (String provincia : province) {
                                                String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.provincia=? and scuole.tipologia_grado_istruzione=? and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI' and vincoli." + vincoli.get(2) + "='SI'";
                                                Cursor cursor = dbm.query(query, new String[]{provincia, grado});
                                                inserimento(cursor);
                                            }
                                            break;
                                        case 4:
                                            for (String provincia : province) {
                                                String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola where scuole.provincia=? and scuole.tipologia_grado_istruzione=? and vincoli." + vincoli.get(0) + "='SI' and vincoli." + vincoli.get(1) + "='SI' and vincoli." + vincoli.get(2) + "='SI' and vincoli." + vincoli.get(3) + "='SI'";
                                                Cursor cursor = dbm.query(query, new String[]{provincia, grado});
                                                inserimento(cursor);
                                            }
                                            break;
                                    }
                                }
                            }

                        }
                    }
                }
            }

        }
    }

    public void inserimento(Cursor cursor){
        while (cursor.moveToNext()) {
            int index,index1;
            index = cursor.getColumnIndexOrThrow("id");
            String snip = cursor.getString(index);

            index = cursor.getColumnIndexOrThrow("nome");
            index1=cursor.getColumnIndexOrThrow("tipologia_grado_istruzione");
            String den = cursor.getString(index)+" - "+cursor.getString(index1);

            index = cursor.getColumnIndexOrThrow("latitudine");
            String lat = cursor.getString(index);

            index = cursor.getColumnIndexOrThrow("longitudine");
            String lng = cursor.getString(index);

            MyItem offsetItem = new MyItem(Double.parseDouble(lat), Double.parseDouble(lng), den, snip);
            mClusterManager.addItem(offsetItem);
        }
        mClusterManager.cluster();
    }

    /**
     * Viene chiamata quando i servizi di localizzazione sono attivi.
     * Aggiungere qui eventuale codice da eseguire in tal caso.
     *
     * @param bundle il bundle passato da Android.
     * @see com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks#onConnected(Bundle)
     */
    @Override
    public void onConnected(Bundle bundle) {
        Log.i(TAG, "location service connected");
    }

    /**
     * Viene chiamata quando i servizi di localizzazione sono sospesi.
     * Aggiungere qui eventuale codice da eseguire in tal caso.
     *
     * @param i un intero che rappresenta il codice della causa della sospenzione.
     * @see com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks#onConnectionSuspended(int)
     */
    @Override
    public void onConnectionSuspended(int i) {
        Log.i(TAG, "location service connection suspended");
        Toast.makeText(this, R.string.conn_suspended, Toast.LENGTH_LONG).show();
    }

    /**
     * Viene chiamata quando la connessione ai servizi di localizzazione viene persa.
     * Aggiungere qui eventuale codice da eseguire in tal caso.
     *
     * @param connectionResult oggetto che rappresenta il risultato della connessione, con le cause della disconnessione ed altre informazioni.
     * @see com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener#onConnectionFailed(ConnectionResult)
     */
    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Log.e(TAG, "location service connection lost");
        Toast.makeText(this, R.string.conn_failed, Toast.LENGTH_LONG).show();
    }


    /**
     * Viene chiamato quando si clicca sulla mappa.
     * Aggiungere qui codice che si vuole eseguire quando l'utente clicca sulla mappa.
     *
     * @param latLng la posizione del click.
     */
    @Override
    public void onMapClick(LatLng latLng) {

    }

    /**
     * Viene chiamato quando si clicca a lungo sulla mappa (long click).
     * Aggiungere qui codice che si vuole eseguire quando l'utente clicca a lungo sulla mappa.
     *
     * @param latLng la posizione del click.
     */
    @Override
    public void onMapLongClick(LatLng latLng) {

    }

    /**
     * Viene chiamato quando si muove la camera.
     * Attenzione: solamente al momento in cui la camera comincia a muoversi, non durante tutta la durata del movimento.
     *
     * @param reason
     */
    @Override
    public void onCameraMoveStarted(int reason) {

    }


    /**
     * Questo metodo è molto importante: esso viene invocato dal sistema quando la mappa è pronta.
     * Il parametro è l'oggetto di tipo GoogleMap pronto all'uso, che viene immediatamente assegnato ad un campo interno della
     * classe.
     * La natura asincrona di questo metodo, e quindi dell'inizializzazione del campo gMap, implica che tutte le
     * operazioni che coinvolgono la mappa e che vanno eseguite appena essa diventa disponibile, vanno messe in questo metodo.
     * Ciò non significa che tutte le operazioni che coinvolgono la mappa vanno eseguite qui: è naturale aver bisogno di accedere al campo
     * gMap in altri metodi, per eseguire operazioni sulla mappa in vari momenti, ma è necessario tenere a mente che tale campo potrebbe
     * essere ancora non inizializzato e va pertanto verificata la nullness.
     *
     * @param googleMap oggetto di tipo GoogleMap.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        gMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MapsActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSIONS_REQUEST_ACCESS_BOTH_LOCATION);
        } else {
            gMap.setMyLocationEnabled(true);
        }

        gMap.setOnMapClickListener(this);
        gMap.setOnMapLongClickListener(this);
        gMap.setOnCameraMoveStartedListener(this);
        gMap.setOnMarkerClickListener(this);

        UiSettings uis = gMap.getUiSettings();
        uis.setZoomGesturesEnabled(true);
        uis.setMyLocationButtonEnabled(true);
        gMap.setOnMyLocationButtonClickListener(
                new GoogleMap.OnMyLocationButtonClickListener() {
                    @Override
                    public boolean onMyLocationButtonClick() {
                        gpsCheck();
                        return false;
                    }
                });
        uis.setCompassEnabled(true);
        uis.setZoomControlsEnabled(true);
        uis.setMapToolbarEnabled(true);

        applyMapSettings();

        setUpClusterer(getApplicationContext());
        gMap.setOnInfoWindowClickListener(this);
    }

    /**
     * Metodo proprietario che forza l'applicazione le impostazioni (o preferenze) che riguardano la mappa.
     */
    protected void applyMapSettings() {
        if (gMap != null) {
            Log.d(TAG, "applying map settings");
            gMap.setMapType(SettingsActivity.getMapStyle(this));
        }
    }

    /**
     * Naviga dalla posizione from alla posizione to chiamando il navigatore di Google.
     *
     * @param from posizione iniziale.
     * @param to   posizione finale.
     */
    protected void navigate(@NonNull LatLng from, @NonNull LatLng to) {
        Intent navigation = new Intent(
                Intent.ACTION_VIEW,
                Uri.parse("http://maps.google.com/maps?saddr=" + from.latitude + "," + from.longitude + "&daddr=" + to.latitude + "," + to.longitude + ""));
        navigation.setPackage("com.google.android.apps.maps");
        Log.i(TAG, String.format("starting navigation from %s to %s", from, to));
        startActivity(navigation);
    }


    /**
     * Callback che viene invocata quando viene cliccato un marker.
     * Questo metodo viene invocato al click di QUALUNQUE marker nella mappa; pertanto, se è necessario
     * eseguire comportamenti specifici per un certo marker o gruppo di marker, va modificato questo metodo
     * con codice che si occupa di discernere tra un marker e l'altro in qualche modo.
     *
     * @param marker il marker che è stato cliccato.
     * @return ritorna true per continuare a chiamare altre callback nella catena di callback per i marker; false altrimenti.
     */
    @Override
    public boolean onMarkerClick(final Marker marker) {
        marker.showInfoWindow();
        return false;
    }


    /**
     * Controlla lo stato del GPS e dei servizi di localizzazione, comportandosi di conseguenza.
     * Viene usata durante l'inizializzazione ed in altri casi speciali.
     */
    protected void gpsCheck() {
        GoogleApiClient googleApiClient = new GoogleApiClient.Builder(MapsActivity.this).addApi(LocationServices.API).build();
        googleApiClient.connect();

        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(locationRequest);
        builder.setAlwaysShow(true);

        PendingResult<LocationSettingsResult> result = LocationServices.SettingsApi.checkLocationSettings(googleApiClient, builder.build());
        result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
            @Override
            public void onResult(@NonNull LocationSettingsResult result) {
                final Status status = result.getStatus();
                switch (status.getStatusCode()) {
                    case LocationSettingsStatusCodes.SUCCESS:
                        Log.i(TAG, "All location settings are satisfied.");
                        break;
                    case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                        Log.i(TAG, "Location settings are not satisfied. Show the user a dialog to upgrade location settings ");
                        try {
                            // Show the dialog by calling startResolutionForResult(), and check the result
                            // in onActivityResult().
                            status.startResolutionForResult(MapsActivity.this, REQUEST_CHECK_SETTINGS);
                        } catch (IntentSender.SendIntentException e) {
                            Log.i(TAG, "PendingIntent unable to execute request.");
                        }
                        break;
                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                        Log.i(TAG, "Location settings are inadequate, and cannot be fixed here. Dialog not created.");
                        break;
                }
            }
        });
    }


    private ClusterManager<MyItem> mClusterManager;
    private void setUpClusterer(Context context) {
        mClusterManager = new ClusterManager<MyItem>(context, gMap);
        gMap.setOnCameraIdleListener(mClusterManager);
        gMap.setOnMarkerClickListener(mClusterManager);
        String query = "select * from scuole inner join vincoli on scuole.id=vincoli.id_scuola";
        Cursor cursor = dbm.query(query, null);

        while(cursor.moveToNext()) {
            int index,index1;
            index = cursor.getColumnIndexOrThrow("id");
            String snip = cursor.getString(index);

            index = cursor.getColumnIndexOrThrow("nome");
            index1=cursor.getColumnIndexOrThrow("tipologia_grado_istruzione");
            String den = cursor.getString(index)+" - "+cursor.getString(index1);


            index = cursor.getColumnIndexOrThrow("latitudine");
            String lat = cursor.getString(index);


            index = cursor.getColumnIndexOrThrow("longitudine");
            String lng = cursor.getString(index);

            MyItem offsetItem = new MyItem(Double.parseDouble(lat), Double.parseDouble(lng), den, snip);
            mClusterManager.addItem(offsetItem);
        }

    }


    @Override
    public void onInfoWindowClick(Marker marker) {
        Intent intent=new Intent(getApplicationContext(), ScrollingActivityScuola.class);
        intent.putExtra("Codicescuola",marker.getSnippet());
        startActivity(intent);
    }



}